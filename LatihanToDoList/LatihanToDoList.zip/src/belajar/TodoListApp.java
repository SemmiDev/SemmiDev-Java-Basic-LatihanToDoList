package belajar;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class TodoListApp {
    static String fileName = "test.txt";
    static ArrayList<String> todoLists;
    static boolean isEditing = false;
    static Scanner input;

    public static void main(String[] args) {
        // initialize
        todoLists = new ArrayList<>();
        input = new Scanner(System.in);
        System.out.println("FILE: " + fileName);

        // run the program
        while (true) {
            showMenu();
        }
    }


    static void clearScreen() {
        try {
            if (System.getProperty("os.name").contains("Windows")){
                new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033\143");
            }
        } catch (Exception ex) {
            System.out.println("tidak bisa clear screen");
        }
    }

    static  void showMenu(){
        System.out.println(" ====== TODO LIST APP =====");
        System.out.println("[1] Lihat todo List");
        System.out.println("[2] Tambah Todo List");
        System.out.println("[3] Edit Todo List");
        System.out.println("[4] Hapus Todo List");
        System.out.println("[0] Keluar");
        System.out.println(" -------------------- ");

        System.out.print("Pilih menu : ");
        String selectedMenu = input.nextLine();
        if(selectedMenu.equals("1")){
            showTodoList();
        }else if(selectedMenu.equals("2")){
            addToList();
        }else if(selectedMenu.equals("3")){
            editToDoList();
        }else if(selectedMenu.equals("4")){
            deleteToDoList();
        }else if(selectedMenu.equals("0")){
            System.exit(0);
        }else{
            System.err.println("Kamu salah memlilih menu");
            backTomenu();
        }
    }

    static void backTomenu(){
        System.out.println("");
        System.out.println("Tekan [Enter] untuk kembali...");
        input.nextLine();
        clearScreen();
    }

    static void readTodoList(){
        try{
            File file  = new File(fileName);
            Scanner fileReader = new Scanner(file);
            // load
            todoLists.clear();
            while(fileReader.hasNextLine()){
                String data = fileReader.nextLine();
                todoLists.add(data);
            }
        } catch (FileNotFoundException e) {
            System.err.println("error karena : " + e.getMessage());
        }
    }

    static void showTodoList(){
        clearScreen();
        readTodoList();
        if(todoLists.size() > 0){
            System.out.println("===== TODO LIST =====");
            int index = 0;
            for(String data : todoLists){
                System.out.println(String.format("[%d] %s", index,data));
                index++;
            }
        }else{
            System.out.println("tidak ada data!");
        }

        if(!isEditing){
            backTomenu();
        }
    }

    static void addToList(){
        clearScreen();
        System.out.println("Apa yang mau kamu kerjakan");
        System.out.print("Jawab : ");
        String newTodoList = input.nextLine();

        try{
            // tulis file
            FileWriter fileWriter = new FileWriter(fileName,true);
            fileWriter.append(String.format("%s%n", newTodoList));
            fileWriter.close();
            System.out.println("berhasil ditambahkan");
        } catch (IOException e) {
            System.err.println("terjadi kesalahan karena : " + e.getMessage());
        }
        backTomenu();
    }

    static void editToDoList(){
        System.out.println(" ---------- ");
        System.out.print("Pilih indec : ");
        int index = Integer.parseInt(input.nextLine());
        if(index > todoLists.size()){
            throw new IndexOutOfBoundsException("kamu memasukkan data yang salah");
        }else{
            System.out.print("Data baru : ");
            String newData= input.nextLine();

            // update data
            todoLists.set(index,newData);
            System.out.println(todoLists.toString());

            try{
                FileWriter fileWriter = new FileWriter(fileName,false);
                fileWriter.close();
                System.out.println("data berhasil diubah");
            } catch (IOException e) {
                System.err.println("terjadi kesalahan : " + e.getMessage());
            }
        }
        isEditing = false;
        backTomenu();
    }

        static void deleteToDoList(){
        isEditing = true;
        showTodoList();

            System.out.println("------------");
            System.out.print("Pilih indeks : ");
            int index = Integer.parseInt(input.nextLine());

            try{
                if(index > todoLists.size()){
                    throw new IndexOutOfBoundsException("Kamu memasukkan data yang salah");
                }else{
                    System.out.println("Kamu akan menghapus:");
                    System.out.println(String.format("[%d] s", index,todoLists.get(index)));
                    System.out.print("Apa kamu yakin? (y/t)");
                    String jawab = input.nextLine();
                    if(jawab.equalsIgnoreCase("y")){
                        todoLists.remove(index);
                        // tulis ulang file
                        try{
                            FileWriter fileWriter = new FileWriter(fileName,false);
                            // write new data
                            for(String data : todoLists ){
                                fileWriter.append(String.format("%s%n", data));
                            }
                            fileWriter.close();
                            System.out.println("berhasil dihapus");
                        } catch (IOException e) {
                            System.err.println("ada error : " + e.getMessage());
                            e.printStackTrace();
                        }
                    }
                }
            }catch (Exception e) {
                System.out.println(e.getMessage());
            }
            isEditing = false;
            backTomenu();
        }

}
